System.register("chunks:///_virtual/hall",[],(function(){"use strict";return{execute:function(){}}}));
